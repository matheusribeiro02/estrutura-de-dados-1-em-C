#include <stdio.h>
#include <stdlib.h>
#include "ListaDinEncad.h"
int main(){
    struct aluno al, a[4] = {{2,"Andre",9.5,7.8,8.5},
                         {4,"Ricardo",7.5,8.7,6.8},
                         {1,"Bianca",9.7,6.7,8.4},
                         {3,"Ana",5.7,6.1,7.4}};
    Lista* li = cria_lista();
    printf("Tamanho: %d\n\n",tamanho_lista(li));
    int i, pos;
    for(i=0; i < 4; i++)
        insere_lista_ordenada(li,a[i]);
    
    printf("Tamanho: %d\n\n",tamanho_lista(li));
    
	pos = consultaEndereco(li, 4);
	//divideLista(li,2);

//	consulta(li, 2, &al);
//	printf("%s", al);
	printf("Endereco %d", pos);
	
	//printf("\n Posi??o %d", consulta_lista_pos(li, 2, al))
	printf("\n-----------------\n"); 
	
    imprime_lista(li);
    //printf("\nTamanho: %d\n",tamanho_lista(li));
    
    trocaCampo(li, 1, 2);
    
    printf("\n--------Depois da troca---------\n");
    
    imprime_lista(li);

    libera_lista(li);
    system("pause");
    return 0;
}



