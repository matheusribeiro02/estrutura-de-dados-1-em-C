#include <stdio.h>
#include <stdlib.h>
#include "ListaDinEncadDupla.h"
int main(){
    struct aluno al, a[4] = {{2,"Andre",9.5,7.8,8.5},
                         {4,"Ricardo",7.5,8.7,6.8},
                         {1,"Bianca",9.7,6.7,8.4},
                         {3,"Ana",5.7,6.1,7.4}};
    Lista* li = cria_lista();

    int i;
    for(i=0; i < 4; i++)
       insere_lista_ordenada(li,a[i]);
        
    
    struct aluno b[4] = {{5,"Matheus",9.5,7.8,8.5},
                         {8,"Dudu",7.5,8.7,6.8},
                         {6,"Raphael",9.7,6.7,8.4},
                         {7,"Veiga",5.7,6.1,7.4}};
    Lista* li_2 = cria_lista();

    for(i=0; i < 4; i++)
        insere_lista_ordenada(li_2,b[i]);
        
    
    struct aluno c[4] = {{9,"Jon",9.5,7.8,8.5},
                         {10,"Sam",7.5,8.7,6.8},
                         {11,"Dean",9.7,6.7,8.4},
                         {12,"Castiel",5.7,6.1,7.4}};
    Lista* li_3 = cria_lista();

    for(i=0; i < 4; i++)
        insere_lista_ordenada(li_3,c[i]);

    
	Lista* li_4 = cria_lista();
	
    //QUESTAO 3
	intercala(li, li_2, li_3, li_4);
    
    imprime_lista(li_4);
 
    libera_lista(li);
    libera_lista(li_2);
    libera_lista(li_3);
    libera_lista(li_4);
    system("pause");
    return 0;
}

